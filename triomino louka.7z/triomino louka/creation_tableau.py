def creation_tableau(taille):
    tab = []
    for i in range (taille):
        tab_tmp=[0]*taille
        tab.append(tab_tmp)
    return tab   

