import tkinter as tk
from case_noire import *
from creation_tableau import *
from maj_tab import *
from resoudre_tableau import *
from trouve_case_occupee import *
from random import *
import time

root = tk.Tk()

cells = []
def draw(grille): # Créé une grille vide
    for r, row in enumerate(grille):
        cell_row = []
        for c, value in enumerate(row):
            cell = tk.Label(
                root,
                width=2,
                height=1,
                bg="white",
                highlightbackground="white",
                highlightthickness=1
            )
            cell.grid(row=r, column=c, ipadx=cell_size, ipady=cell_size)

            cell_row.append(cell)
        cells.append(cell_row)

def redraw(grille): # Utilise la copie de la grille pour voir quelles cases ont été modifiées
    global previous, color_map

    changed = []

    for r, row in enumerate(grille): # Crée changed pour les cases différentes de celles dans previous
        for c, value in enumerate(row):
            if value != previous[r][c] and value in [-1, 1]:
                changed.append((r, c))

    if len(changed) > 0: # Ajoute dans color_map les cases modifiées avec une nouvelle couleur
        new_color = "#{:06x}".format(randint(0, 0xFFFFFF))
        for r, c in changed:
            color_map[r][c] = new_color

    for r, c in changed: # Update les couleurs conformément
        cells[r][c].config(bg=color_map[r][c])


    root.update()

    previous = [row[:] for row in grille] # Copie la nouvelle grille actuelle en tant que previous

    time.sleep(delay)



def resoudre_tableau(grille,x,y,delta):
    orientation=trouve_case_occupee(grille, x, y, delta)
    if delta ==2:  
        maj_tableau(grille,x,y,orientation)
        redraw(grille)
    else:
        delta=delta//2
        maj_tableau(grille,x+delta-1,y+delta-1,orientation)
        redraw(grille)
        resoudre_tableau(grille,x,y,delta)
        resoudre_tableau(grille,x+delta,y,delta)
        resoudre_tableau(grille,x,y+delta,delta)
        resoudre_tableau(grille,x+delta,y+delta,delta)

taille = 32
cell_size = taille//8
delay = 0.005

grille = creation_tableau(taille)
case_noire(grille)

draw(grille)

global previous, color_map

previous = [row[:] for row in grille] # Créé une copie grace au splitting de grille
color_map = [["white" for _ in row] for row in grille] # Créé une liste de listes des couleurs

resoudre_tableau(grille, 0, 0, taille)

root.mainloop()
